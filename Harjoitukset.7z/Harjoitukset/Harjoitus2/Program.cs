﻿// Ohjelma: Lotto

using System;
using System.Collections.Generic;

namespace Harjoitus2
{
    class Program
    {
        static void Main(string[] args)
        {
            var numerot = new List<int>();
            Random r = new Random();

            Console.Write("Kuinka monta lottorivia > ");
            int rivit = int.Parse(Console.ReadLine());

            for (int i = 1; i <= rivit; ++i)
            {
                numerot.Clear(); // Tyhjenna lista

                for (int j = 0; j < 7; ++j)
                {
                    int tmp_num = r.Next(0, 40);
                    if (!(j > 0 && numerot.Contains(tmp_num))) // Onko satunnaisnumero listassa
                    {
                        numerot.Add(tmp_num);
                    }
                    else
                    {
                        --j;
                    }
                }

                Console.Write("Rivi " + i + ": ");
                for (int j = 0; j < 7; ++j)
                {
                    Console.Write(numerot[j]);
                    if (j < 6)
                    {
                        Console.Write(", ");
                    }
                }
                Console.Write('\n');
            }
        }
    }
}
