﻿// Ohjelma: Lotto

using System;

namespace Harjoitus2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numerot = new int[7];
            Random r = new Random();
            Console.Write("Kuinka monta lottorivia > ");
            int rivit = int.Parse(Console.ReadLine());

            for (int i = 1; i <= rivit; ++i)
            {
                for (int j = 0; j < 7; ++j)
                {
                    int rInt = r.Next(1, 40);
                    numerot[j] = rInt;
                }

                Console.Write("Rivi " + i + ": " + numerot[0] + ", " + numerot[1] + ", " + 
                    numerot[2] + ", " + numerot[3] + ", " + numerot[4] + ", " + 
                    numerot[5] + ", " + numerot[6] + '\n');
            }
        }
    }
}
